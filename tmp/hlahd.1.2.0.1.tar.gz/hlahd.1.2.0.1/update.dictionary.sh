#This shell command updates hla dictionary
#Please ensure the release version at ftp://ftp.ebi.ac.uk/pub/databases/ipd/imgt/hla/
#Wget program (https://www.gnu.org/software/wget/) is need to run the command.

wget ftp://ftp.ebi.ac.uk/pub/databases/ipd/imgt/hla/hla.dat 

if [ -e ./bin/create_fasta_from_dat ]; then
:
else
g++ ./src/Create_fasta_from_dat.cpp -O3 -o ./bin/create_fasta_from_dat
fi

if [ -e dictionary ]; then
:
else
mkdir dictionary
fi

mv hla.dat ./dictionary

./bin/create_fasta_from_dat dictionary/hla.dat dictionary/ 150

cd dictionary
sh create_dir.sh
sh move_file.sh
sh bw_build.sh
cd ../
